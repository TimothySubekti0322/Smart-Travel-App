<?php

if(!isset($_COOKIE['payload'])){
    header("Location: localhost:8080/login");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Analytics</title>
</head>
<body>
    This is Book Analytics Page
</body>
</html>